# Inventory Backend (Django + Django REST Framework)

## Setup
```bash
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
python manage.py makemigrations inventory
python manage.py migrate
python manage.py seed --email admin@example.com --password admin123
python manage.py runserver
```

## Flow chart -> Endpoint
| Flow chart | Endpoint |
|---|---|
| Register / Credentials INVALID | `POST /api/auth/register/` |
| Log in (may role + redirect) | `POST /api/auth/login/` |
| Log out | `POST /api/auth/logout/` |
| Select category | `GET /api/categories/` |
| Show models | `GET /api/categories/<id>/models/` |
| User: enter part info -> save | `POST /api/user/parts/` |
| User: view saved | `GET /api/user/parts/` |
| Admin: show parts | `GET /api/admin/parts/?category_id=&model_id=` |
| Admin: add information | `POST /api/admin/parts/` |
| Admin: update parts/date/serial/location/status | `PATCH /api/admin/parts/<id>/` |
| Admin: request part | `POST /api/admin/part-requests/` |
| Admin: add model | `POST /api/admin/models/` |

Header para sa lahat maliban register/login: `Authorization: Token <token>`

Admin = account na `is_staff=True`. Pwede ring i-manage sa `/django-admin/`.
