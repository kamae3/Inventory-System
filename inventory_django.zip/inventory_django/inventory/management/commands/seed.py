from django.contrib.auth.models import User
from django.core.management.base import BaseCommand

from inventory.models import Category


class Command(BaseCommand):
    help = "Gumawa ng categories (DESKTOP, POS, CLIQQ) at admin account."

    def add_arguments(self, parser):
        parser.add_argument("--email", default="admin@example.com")
        parser.add_argument("--password", default="admin123")

    def handle(self, *args, **opts):
        for name in ["DESKTOP", "POS", "CLIQQ"]:
            Category.objects.get_or_create(name=name)

        email = opts["email"].lower()
        if not User.objects.filter(username=email).exists():
            User.objects.create_superuser(
                username=email, email=email, password=opts["password"], first_name="Administrator"
            )
            self.stdout.write(self.style.SUCCESS(f"Admin created: {email}"))
        self.stdout.write(self.style.SUCCESS("Seed done."))
